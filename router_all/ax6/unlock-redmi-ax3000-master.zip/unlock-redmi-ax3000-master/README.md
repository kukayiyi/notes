### How to use
- [红米 AX3000 \(AX6\) 解锁 SSH 教程](https://xn--m80a.ml/openwrt/dev/10.html)

### Reference
- [\[原创\]红米AX6 SSH解锁和挂载overlay方法](https://www.right.com.cn/forum/thread-4060726-1-1.html)
- [小米ax3600获取root权限【简单快速】【修复丢ssid】](https://www.right.com.cn/forum/thread-4046020-1-1.html)
- [paldier/ax3600_tool](https://github.com/paldier/ax3600_tool)

### SHA256SUM
9e23df6dfef90a6eeb200ce16793f4a3baca0de664d709944263058df77646f8  fuckax3000
f25660739ad3b44fe8230af1f7c5f9e8e2cd7f3c67c7576457cffcf5dbe8f108  miwifi_ra69_firmware_45a77_1.0.18.bin
